import React from 'react'
import img from "../logo.svg"


function New() {
    return (
        <>
            <h1 class="text-red-600 underline text-4xl ">Hello</h1>
            <div class="h-80 w-80 bg-slate-950 rounded-[30px]">
                <img src={img} alt="" />
            </div>
        </>
    )
}

function New1() {
    return (
        <>
            <h1>Hello</h1>
        </>
    )
}
function New2() {
    return (
        <>
            <h1>Hello</h1>
        </>
    )
}
function New3() {
    return (
        <>
            <h1>Hello</h1>
        </>
    )
}
export { New, New1 ,New2, New3}

