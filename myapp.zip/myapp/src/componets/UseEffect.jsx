import React from 'react'

export default function useEffect() {


  useEffect(() => {
    console.log("hii my name is abhi");
  }, [])


  return (
    <>



    </>
  )
}
