import React from "react";
import img from "../Assets/vk.jpeg"

function Main() {
    return (
        <div>
            <div>
                <heading class="font-bold text-3xl ml-7 flex text-gray-800"><h1>Budget-Friendly Bargains</h1></heading>
            </div>
            <div class=" flex">
                <box class="h-[350px] w-48 ml-2 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-4 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
            </div>
            <div class=" flex">
                <box class="h-[350px] w-48 ml-2 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
                <box class="h-[350px] w-48 ml-1 mt-1 bg-black rounded-[20px]">
                    <img src="" class=" " alt="" />
                </box>
            </div>
        </div>
    )
}
export default Main;